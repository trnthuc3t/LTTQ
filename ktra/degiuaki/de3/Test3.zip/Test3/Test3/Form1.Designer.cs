﻿namespace Test3
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.country = new System.Windows.Forms.GroupBox();
			this.radioButton10 = new System.Windows.Forms.RadioButton();
			this.co8 = new System.Windows.Forms.RadioButton();
			this.co7 = new System.Windows.Forms.RadioButton();
			this.co6 = new System.Windows.Forms.RadioButton();
			this.co5 = new System.Windows.Forms.RadioButton();
			this.co4 = new System.Windows.Forms.RadioButton();
			this.co3 = new System.Windows.Forms.RadioButton();
			this.co2 = new System.Windows.Forms.RadioButton();
			this.co1 = new System.Windows.Forms.RadioButton();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.ca1 = new System.Windows.Forms.RadioButton();
			this.ca2 = new System.Windows.Forms.RadioButton();
			this.ca3 = new System.Windows.Forms.RadioButton();
			this.ca4 = new System.Windows.Forms.RadioButton();
			this.ca5 = new System.Windows.Forms.RadioButton();
			this.ca6 = new System.Windows.Forms.RadioButton();
			this.ca8 = new System.Windows.Forms.RadioButton();
			this.ca7 = new System.Windows.Forms.RadioButton();
			this.lbChon = new System.Windows.Forms.Label();
			this.btnExit = new System.Windows.Forms.Button();
			this.country.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// country
			// 
			this.country.Controls.Add(this.radioButton10);
			this.country.Controls.Add(this.co8);
			this.country.Controls.Add(this.co7);
			this.country.Controls.Add(this.co6);
			this.country.Controls.Add(this.co5);
			this.country.Controls.Add(this.co4);
			this.country.Controls.Add(this.co3);
			this.country.Controls.Add(this.co2);
			this.country.Controls.Add(this.co1);
			this.country.Location = new System.Drawing.Point(59, 31);
			this.country.Name = "country";
			this.country.Size = new System.Drawing.Size(355, 366);
			this.country.TabIndex = 0;
			this.country.TabStop = false;
			this.country.Text = "Country";
			// 
			// radioButton10
			// 
			this.radioButton10.AutoSize = true;
			this.radioButton10.Location = new System.Drawing.Point(421, 71);
			this.radioButton10.Name = "radioButton10";
			this.radioButton10.Size = new System.Drawing.Size(103, 20);
			this.radioButton10.TabIndex = 0;
			this.radioButton10.TabStop = true;
			this.radioButton10.Text = "radioButton1";
			this.radioButton10.UseVisualStyleBackColor = true;
			// 
			// co8
			// 
			this.co8.AutoSize = true;
			this.co8.Location = new System.Drawing.Point(22, 327);
			this.co8.Name = "co8";
			this.co8.Size = new System.Drawing.Size(83, 20);
			this.co8.TabIndex = 0;
			this.co8.TabStop = true;
			this.co8.Text = "The USA";
			this.co8.UseVisualStyleBackColor = true;
			// 
			// co7
			// 
			this.co7.AutoSize = true;
			this.co7.Location = new System.Drawing.Point(22, 283);
			this.co7.Name = "co7";
			this.co7.Size = new System.Drawing.Size(52, 20);
			this.co7.TabIndex = 0;
			this.co7.TabStop = true;
			this.co7.Text = "Italy";
			this.co7.UseVisualStyleBackColor = true;
			// 
			// co6
			// 
			this.co6.AutoSize = true;
			this.co6.Location = new System.Drawing.Point(22, 242);
			this.co6.Name = "co6";
			this.co6.Size = new System.Drawing.Size(73, 20);
			this.co6.TabIndex = 0;
			this.co6.TabStop = true;
			this.co6.Text = "The UK";
			this.co6.UseVisualStyleBackColor = true;
			// 
			// co5
			// 
			this.co5.AutoSize = true;
			this.co5.Location = new System.Drawing.Point(22, 204);
			this.co5.Name = "co5";
			this.co5.Size = new System.Drawing.Size(70, 20);
			this.co5.TabIndex = 0;
			this.co5.TabStop = true;
			this.co5.Text = "Turkey";
			this.co5.UseVisualStyleBackColor = true;
			// 
			// co4
			// 
			this.co4.AutoSize = true;
			this.co4.Location = new System.Drawing.Point(22, 156);
			this.co4.Name = "co4";
			this.co4.Size = new System.Drawing.Size(63, 20);
			this.co4.TabIndex = 0;
			this.co4.TabStop = true;
			this.co4.Text = "Spain";
			this.co4.UseVisualStyleBackColor = true;
			// 
			// co3
			// 
			this.co3.AutoSize = true;
			this.co3.Location = new System.Drawing.Point(22, 112);
			this.co3.Name = "co3";
			this.co3.Size = new System.Drawing.Size(79, 20);
			this.co3.TabIndex = 0;
			this.co3.TabStop = true;
			this.co3.Text = "Hungary";
			this.co3.UseVisualStyleBackColor = true;
			// 
			// co2
			// 
			this.co2.AutoSize = true;
			this.co2.Location = new System.Drawing.Point(22, 71);
			this.co2.Name = "co2";
			this.co2.Size = new System.Drawing.Size(66, 20);
			this.co2.TabIndex = 0;
			this.co2.TabStop = true;
			this.co2.Text = "Japan";
			this.co2.UseVisualStyleBackColor = true;
			// 
			// co1
			// 
			this.co1.AutoSize = true;
			this.co1.Location = new System.Drawing.Point(22, 32);
			this.co1.Name = "co1";
			this.co1.Size = new System.Drawing.Size(70, 20);
			this.co1.TabIndex = 0;
			this.co1.TabStop = true;
			this.co1.Text = "France";
			this.co1.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.ca1);
			this.groupBox2.Controls.Add(this.ca8);
			this.groupBox2.Controls.Add(this.ca7);
			this.groupBox2.Controls.Add(this.ca6);
			this.groupBox2.Controls.Add(this.ca5);
			this.groupBox2.Controls.Add(this.ca4);
			this.groupBox2.Controls.Add(this.ca3);
			this.groupBox2.Controls.Add(this.ca2);
			this.groupBox2.Location = new System.Drawing.Point(447, 31);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(363, 366);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Capital";
			// 
			// ca1
			// 
			this.ca1.AutoSize = true;
			this.ca1.Location = new System.Drawing.Point(33, 32);
			this.ca1.Name = "ca1";
			this.ca1.Size = new System.Drawing.Size(108, 20);
			this.ca1.TabIndex = 0;
			this.ca1.TabStop = true;
			this.ca1.Text = "Buenos Aires";
			this.ca1.UseVisualStyleBackColor = true;
			// 
			// ca2
			// 
			this.ca2.AutoSize = true;
			this.ca2.Location = new System.Drawing.Point(33, 71);
			this.ca2.Name = "ca2";
			this.ca2.Size = new System.Drawing.Size(67, 20);
			this.ca2.TabIndex = 0;
			this.ca2.TabStop = true;
			this.ca2.Text = "Tokyo";
			this.ca2.UseVisualStyleBackColor = true;
			// 
			// ca3
			// 
			this.ca3.AutoSize = true;
			this.ca3.Location = new System.Drawing.Point(33, 112);
			this.ca3.Name = "ca3";
			this.ca3.Size = new System.Drawing.Size(65, 20);
			this.ca3.TabIndex = 0;
			this.ca3.TabStop = true;
			this.ca3.Text = "Rome";
			this.ca3.UseVisualStyleBackColor = true;
			// 
			// ca4
			// 
			this.ca4.AutoSize = true;
			this.ca4.Location = new System.Drawing.Point(33, 156);
			this.ca4.Name = "ca4";
			this.ca4.Size = new System.Drawing.Size(70, 20);
			this.ca4.TabIndex = 0;
			this.ca4.TabStop = true;
			this.ca4.Text = "Madrid";
			this.ca4.UseVisualStyleBackColor = true;
			// 
			// ca5
			// 
			this.ca5.AutoSize = true;
			this.ca5.Location = new System.Drawing.Point(33, 204);
			this.ca5.Name = "ca5";
			this.ca5.Size = new System.Drawing.Size(73, 20);
			this.ca5.TabIndex = 0;
			this.ca5.TabStop = true;
			this.ca5.Text = "London";
			this.ca5.UseVisualStyleBackColor = true;
			// 
			// ca6
			// 
			this.ca6.AutoSize = true;
			this.ca6.Location = new System.Drawing.Point(33, 242);
			this.ca6.Name = "ca6";
			this.ca6.Size = new System.Drawing.Size(71, 20);
			this.ca6.TabIndex = 0;
			this.ca6.TabStop = true;
			this.ca6.Text = "Ankara";
			this.ca6.UseVisualStyleBackColor = true;
			// 
			// ca8
			// 
			this.ca8.AutoSize = true;
			this.ca8.Location = new System.Drawing.Point(33, 327);
			this.ca8.Name = "ca8";
			this.ca8.Size = new System.Drawing.Size(59, 20);
			this.ca8.TabIndex = 0;
			this.ca8.TabStop = true;
			this.ca8.Text = "Paris";
			this.ca8.UseVisualStyleBackColor = true;
			// 
			// ca7
			// 
			this.ca7.AutoSize = true;
			this.ca7.Location = new System.Drawing.Point(33, 283);
			this.ca7.Name = "ca7";
			this.ca7.Size = new System.Drawing.Size(86, 20);
			this.ca7.TabIndex = 0;
			this.ca7.TabStop = true;
			this.ca7.Text = "Budapest";
			this.ca7.UseVisualStyleBackColor = true;
			// 
			// lbChon
			// 
			this.lbChon.AutoSize = true;
			this.lbChon.Location = new System.Drawing.Point(99, 416);
			this.lbChon.Name = "lbChon";
			this.lbChon.Size = new System.Drawing.Size(0, 16);
			this.lbChon.TabIndex = 2;
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(651, 435);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(75, 23);
			this.btnExit.TabIndex = 3;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(822, 470);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.lbChon);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.country);
			this.Name = "Form1";
			this.Text = "Capital of country";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.country.ResumeLayout(false);
			this.country.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox country;
		private System.Windows.Forms.RadioButton radioButton10;
		private System.Windows.Forms.RadioButton co8;
		private System.Windows.Forms.RadioButton co7;
		private System.Windows.Forms.RadioButton co6;
		private System.Windows.Forms.RadioButton co5;
		private System.Windows.Forms.RadioButton co4;
		private System.Windows.Forms.RadioButton co3;
		private System.Windows.Forms.RadioButton co2;
		private System.Windows.Forms.RadioButton co1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.RadioButton ca1;
		private System.Windows.Forms.RadioButton ca2;
		private System.Windows.Forms.RadioButton ca8;
		private System.Windows.Forms.RadioButton ca7;
		private System.Windows.Forms.RadioButton ca6;
		private System.Windows.Forms.RadioButton ca5;
		private System.Windows.Forms.RadioButton ca4;
		private System.Windows.Forms.RadioButton ca3;
		private System.Windows.Forms.Label lbChon;
		private System.Windows.Forms.Button btnExit;
	}
}

